<?
echo str_repeat(" ",300);
ignore_user_abort(true); //this way, the user can stop the output, but not the script.
while (true) {
         echo "test<br>\n";
         flush();
         sleep(2);
         if (connection_status()!=0){
                 include ('dbconnect.inc');
                 $sql="delete from online_users where online_user=$user";
                 $sql_exec=pg_exec($vChatDB, $sql);
                 die(); //kills the script
         }
}
?>