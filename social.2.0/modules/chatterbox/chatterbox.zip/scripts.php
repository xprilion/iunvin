<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="scripts.js"></script>

